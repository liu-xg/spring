package com.gupaoedu.vip.pattern.adapter.passport;

/**
 * Created by Tom on 2018/3/14.
 */
public class LoginForSinaAdapter {
}
