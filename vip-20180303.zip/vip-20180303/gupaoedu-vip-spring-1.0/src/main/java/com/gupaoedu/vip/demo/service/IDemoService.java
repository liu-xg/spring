package com.gupaoedu.vip.demo.service;

public interface IDemoService {
	
	String get(String name);
	
}
