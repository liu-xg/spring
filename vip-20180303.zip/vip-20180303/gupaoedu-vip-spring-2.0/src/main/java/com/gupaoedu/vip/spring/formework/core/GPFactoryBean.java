package com.gupaoedu.vip.spring.formework.core;

/**
 * Created by Tom on 2018/4/21.
 */
public class GPFactoryBean {
}
