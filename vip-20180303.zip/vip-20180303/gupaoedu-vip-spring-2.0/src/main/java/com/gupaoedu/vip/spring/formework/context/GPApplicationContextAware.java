package com.gupaoedu.vip.spring.formework.context;

/**
 * Created by Tom on 2018/5/2.
 */
public interface GPApplicationContextAware {

    void setApplicationContext(GPApplicationContext applicationContext);

}
