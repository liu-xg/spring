package com.gupaoedu.vip.pattern.delegate.leader;

/**
 * Created by Tom on 2018/3/14.
 */
public interface ITarget {

    public void doing(String command);

}
