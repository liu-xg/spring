package com.gupaoedu.vip.pattern.delegate.mvc.controllers;

/**
 * Created by Tom on 2018/3/14.
 */
public class OrderAction {

    public void getOrderById(String mid){

    }

}
