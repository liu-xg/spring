package com.gupaoedu.vip.pattern.factory;

import com.gupaoedu.vip.pattern.factory.Milk;

/**
 * Created by Tom on 2018/3/4.
 */
public class Mengniu implements Milk {
    @Override
    public String getName() {
        return "蒙牛";
    }
}
