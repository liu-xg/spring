package com.gupaoedu.vip.pattern.factory;

/**
 * Created by Tom on 2018/3/4.
 */
public class Telunsu implements Milk {
    @Override
    public String getName() {
        return "特仑苏";
    }
}
