package com.gupaoedu.vip.pattern.factory;

/**
 * Created by Tom on 2018/3/4.
 */
public interface Milk {

    /**
     * 获取一个标准产品
     * @return
     */
    public String getName();

}
