package com.gupaoedu.vip.pattern.factory;

/**
 * Created by Tom on 2018/3/4.
 */
public class Sanlu implements  Milk{
    @Override
    public String getName() {
        return "三鹿";
    }
}
