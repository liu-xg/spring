package gupaoedu.vip.pattern.observer.subject;

/**
 * Created by Tom on 2018/3/17.
 */
public enum SubjectEventType {
    ON_ADD,
    ON_RMOVE,
    ON_EDIT,
    ON_QUERY;

}
