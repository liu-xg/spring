package com.gupaoedu.vip.model;

public class Member {

}
