package com.gupaoedu.vip.pattern.singleton.register;

/**
 * Created by Tom on 2018/3/7.
 */
public enum RegiterEnum {
    INSTANCE,BLACK,WHITE;
    public void getInstance(){}

}
