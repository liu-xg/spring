package com.gupaoedu.vip.pattern.singleton.test;

/**
 * Created by Tom on 2018/3/8.
 */
public class Pojo {
}
