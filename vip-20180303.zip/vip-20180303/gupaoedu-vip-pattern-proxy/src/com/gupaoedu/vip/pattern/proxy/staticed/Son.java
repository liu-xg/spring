package com.gupaoedu.vip.pattern.proxy.staticed;

/**
 * Created by Tom on 2018/3/10.
 */
public class Son implements Person{

    public void findLove(){

        //我没有时间
        //工作忙
        System.out.println("找对象，肤白貌美大长腿");
    }

    @Override
    public void zufangzi() {

    }

    @Override
    public void buy() {

    }

    @Override
    public void findJob() {

    }
}
