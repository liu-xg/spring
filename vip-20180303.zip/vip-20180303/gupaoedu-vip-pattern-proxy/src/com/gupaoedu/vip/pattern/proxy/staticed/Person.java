package com.gupaoedu.vip.pattern.proxy.staticed;

/**
 * Created by Tom on 2018/3/10.
 */
public interface Person {

    public void findLove();

    public void zufangzi();

    public void buy();

    public void findJob();

    //......
}
