package com.gupaoedu.vip.pattern.proxy.cglib;

/**
 * Created by Tom on 2018/3/10.
 */
public class ZhangSan {

    public void findLove(){
        System.out.println("肤白貌美大象腿");
    }

}
