package com.gupaoedu.vip.spring5.demo.service;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

/**
 * Created by Tom on 2018/5/13.
 */
@Service
public class MemberService {

    public void get(){

    }

}
