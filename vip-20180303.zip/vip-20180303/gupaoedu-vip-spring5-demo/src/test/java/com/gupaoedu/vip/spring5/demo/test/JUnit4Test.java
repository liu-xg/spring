package com.gupaoedu.vip.spring5.demo.test;

import com.gupaoedu.vip.spring5.demo.service.MemberService;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


//@ContextConfiguration(locations = "classpath:application-context.xml")
//@RunWith(SpringJUnit4ClassRunner.class)
public class JUnit4Test {

//    @Autowired MemberService memberService;
//
//    @Before
//    public void before(){
//        System.out.println("准备好数据");
//    }
//
//    @Test
//    public void test(){
//        System.out.println("执行业务逻辑" + memberService);
//    }
//
//
//    @After
//    public void after(){
//        System.out.println("后置处理");
//    }

}
