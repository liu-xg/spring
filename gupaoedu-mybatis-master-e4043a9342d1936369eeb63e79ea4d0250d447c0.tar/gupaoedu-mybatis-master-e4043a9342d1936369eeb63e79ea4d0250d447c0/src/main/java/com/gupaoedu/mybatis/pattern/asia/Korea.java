package com.gupaoedu.mybatis.pattern.asia;

import com.gupaoedu.mybatis.pattern.AsiaPeople;

/**
 * Created by James on 2017-12-23.
 * From 咕泡学院出品
 * 老师咨询 QQ 2904270631
 */
public class Korea extends AsiaPeople {
    @Override
    protected void dance() {

    }
}
