package com.gupaoedu.mybatis.proxy;

/**
 * Created by James on 2017-06-02.
 * From 咕泡学院出品
 * 老师咨询 QQ 2904270631
 */
public interface IProxyInterface {
    void hello();

    void hello2();
}
