package com.gupaoedu.mybatis.pattern;

/**
 * Created by James on 2017-12-23.
 * From 咕泡学院出品
 * 老师咨询 QQ 2904270631
 */
public abstract class AsiaPeople implements People{
    //黄皮肤
    private String skin;

    protected abstract void dance();
}
