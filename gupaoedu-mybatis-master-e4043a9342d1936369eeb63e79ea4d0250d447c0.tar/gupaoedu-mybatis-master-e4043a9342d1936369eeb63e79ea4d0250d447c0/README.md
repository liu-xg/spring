# 安装一下lombok插件

# VIP使用vip-2.0分支
可以用git branch -a 查看


